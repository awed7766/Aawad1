import asyncio
import logging
import os
import sqlite3
from contextlib import closing
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any

import httpx
from dotenv import load_dotenv
from telegram import InlineKeyboardButton, InlineKeyboardMarkup, LabeledPrice, Update
from telegram.ext import (
	Application,
	ApplicationBuilder,
	CallbackQueryHandler,
	ChatMemberHandler,
	CommandHandler,
	ContextTypes,
	MessageHandler,
	PreCheckoutQueryHandler,
	filters,
)
from settings import CONFIG, DEFAULT_MARGIN_PERCENT

load_dotenv()
logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
LOGGER = logging.getLogger(__name__)

BOT_TOKEN = CONFIG.bot_token
DATABASE_PATH = CONFIG.database_path
CURRENCY = CONFIG.currency
SUPPORT_USERNAME = CONFIG.support_username
ADMIN_IDS = set(CONFIG.legacy_admin_ids)


@dataclass(frozen=True)
class Service:
	service_id: str
	name: str
	category: str
	provider_rate: float
	minimum: int
	maximum: int
	refill: bool


def telegram_category(category: str, name: str) -> str:
	text = f"{category} {name}".lower()
	telegram_words = ("telegram", "تلجرام", "تيليجرام", "قنوات", "قناة", "قروبات", "جروبات", "group")
	if not any(word in text for word in telegram_words):
		return category or "أخرى"
	if any(word in text for word in ("emoji", "reaction", "react", "تفاعل", "ايموجي", "إيموجي")):
		return "تيليجرام - تفاعل بالإيموجي"
	if any(word in text for word in ("view", "views", "مشاهد", "مشاهدة", "مشاهدات")):
		return "تيليجرام - مشاهدات المنشورات"
	if any(word in text for word in ("channel", "قناة", "قنوات", "group", "قروب", "قروبات", "جروب", "جروبات")):
		return "تيليجرام - قنوات وقروبات"
	return "تيليجرام - خدمات أخرى"


class ProviderClient:
	def __init__(self) -> None:
		self.url = CONFIG.provider_api_url
		self.key = CONFIG.provider_api_key

	async def request(self, action: str, **params: Any) -> dict[str, Any]:
		key = text_setting("provider_api_key", self.key)
		if not self.url or not key:
			raise RuntimeError("لم يتم ضبط بيانات API الخاصة بالمزود")
		payload = {"key": key, "action": action, **params}
		async with httpx.AsyncClient(timeout=30) as client:
			response = await client.post(self.url, data=payload)
			response.raise_for_status()
			data = response.json()
		if isinstance(data, dict) and data.get("error"):
			raise RuntimeError(str(data["error"]))
		return data

	async def services(self) -> list[Service]:
		rows = await self.request("services")
		result = []
		for row in rows:
			category = str(row.get("category", "أخرى"))
			name = str(row.get("name", "خدمة بدون اسم"))
			result.append(Service(
				service_id=str(row["service"]),
				name=name,
				category=telegram_category(category, name),
				provider_rate=float(row.get("rate", 0)),
				minimum=int(row.get("min", 1)),
				maximum=int(row.get("max", 1_000_000)),
				refill=bool(row.get("refill", False)),
			))
		return result

	async def add_order(self, service_id: str, link: str, quantity: int) -> str:
		data = await self.request("add", service=service_id, link=link, quantity=quantity)
		return str(data.get("order", data.get("id", "")))

	async def order_status(self, order_id: str) -> dict[str, Any]:
		return await self.request("status", order=order_id)

	async def refill(self, order_id: str) -> str:
		data = await self.request("refill", order=order_id)
		return str(data.get("refill", data.get("id", "")))

	async def balance(self) -> float:
		data = await self.request("balance")
		return float(data.get("balance", 0))


provider = ProviderClient()
service_cache: dict[str, Service] = {}


def db() -> sqlite3.Connection:
	connection = sqlite3.connect(DATABASE_PATH)
	connection.row_factory = sqlite3.Row
	return connection


def init_db() -> None:
	with closing(db()) as connection:
		connection.executescript("""
		CREATE TABLE IF NOT EXISTS users (
			telegram_id INTEGER PRIMARY KEY, username TEXT, first_name TEXT, language_code TEXT,
			balance REAL NOT NULL DEFAULT 0, created_at TEXT NOT NULL
		);
		CREATE TABLE IF NOT EXISTS blocked_users (
			telegram_id INTEGER PRIMARY KEY, username TEXT, first_name TEXT, language_code TEXT,
			blocked_at TEXT NOT NULL
		);
		CREATE TABLE IF NOT EXISTS deposits (
			id INTEGER PRIMARY KEY AUTOINCREMENT, telegram_id INTEGER NOT NULL,
			amount REAL NOT NULL, note TEXT NOT NULL, proof_file_id TEXT,
			status TEXT NOT NULL DEFAULT 'pending', created_at TEXT NOT NULL,
			reviewed_at TEXT, payment_method TEXT NOT NULL DEFAULT 'local',
			stars INTEGER, telegram_charge_id TEXT, refunded_at TEXT,
			refunded_by INTEGER
		);
		CREATE TABLE IF NOT EXISTS orders (
			id INTEGER PRIMARY KEY AUTOINCREMENT, telegram_id INTEGER NOT NULL,
			provider_order_id TEXT, service_id TEXT NOT NULL, service_name TEXT NOT NULL,
			link TEXT NOT NULL, quantity INTEGER NOT NULL, cost REAL NOT NULL, notified_status TEXT,
			status TEXT NOT NULL DEFAULT 'pending', created_at TEXT NOT NULL
		);
		CREATE TABLE IF NOT EXISTS settings (name TEXT PRIMARY KEY, value TEXT NOT NULL);
		CREATE TABLE IF NOT EXISTS admins (
			telegram_id INTEGER PRIMARY KEY, username TEXT NOT NULL DEFAULT '', display_name TEXT NOT NULL DEFAULT '', role TEXT NOT NULL DEFAULT 'moderator',
			permissions TEXT NOT NULL DEFAULT 'deposits,tutorials,buttons,support,broadcast',
			enabled INTEGER NOT NULL DEFAULT 1,
			created_at TEXT NOT NULL
		);
		CREATE TABLE IF NOT EXISTS tutorials (
			service_id TEXT PRIMARY KEY, content TEXT NOT NULL DEFAULT '', photo_file_id TEXT,
			media_type TEXT NOT NULL DEFAULT 'photo',
			updated_by INTEGER NOT NULL, updated_at TEXT NOT NULL
		);
			CREATE TABLE IF NOT EXISTS local_services (
				service_id TEXT PRIMARY KEY, name TEXT NOT NULL, category TEXT NOT NULL,
				provider_rate REAL NOT NULL, minimum INTEGER NOT NULL, maximum INTEGER NOT NULL,
				refill INTEGER NOT NULL DEFAULT 0, enabled INTEGER NOT NULL DEFAULT 1,
				created_by INTEGER NOT NULL, created_at TEXT NOT NULL
			);
		CREATE TABLE IF NOT EXISTS custom_buttons (
			id INTEGER PRIMARY KEY AUTOINCREMENT, label TEXT NOT NULL, content TEXT NOT NULL,
			url TEXT, button_type TEXT NOT NULL DEFAULT 'content', enabled INTEGER NOT NULL DEFAULT 1,
			color TEXT NOT NULL DEFAULT 'blue', reply TEXT NOT NULL DEFAULT '', alert INTEGER NOT NULL DEFAULT 0, clicks INTEGER NOT NULL DEFAULT 0,
			position INTEGER NOT NULL DEFAULT 0, created_at TEXT NOT NULL
		);
		CREATE TABLE IF NOT EXISTS auto_replies (
			keyword TEXT PRIMARY KEY, response TEXT NOT NULL, enabled INTEGER NOT NULL DEFAULT 1,
			created_at TEXT NOT NULL
		);
		""")
		try:
			connection.execute("ALTER TABLE custom_buttons ADD COLUMN button_type TEXT NOT NULL DEFAULT 'content'")
		except sqlite3.OperationalError:
			pass
		for column, definition in (("color", "TEXT NOT NULL DEFAULT 'blue'"), ("reply", "TEXT NOT NULL DEFAULT ''"), ("alert", "INTEGER NOT NULL DEFAULT 0"), ("clicks", "INTEGER NOT NULL DEFAULT 0"), ("position", "INTEGER NOT NULL DEFAULT 0")):
			try:
				connection.execute(f"ALTER TABLE custom_buttons ADD COLUMN {column} {definition}")
			except sqlite3.OperationalError:
				pass
		try:
			connection.execute("ALTER TABLE tutorials ADD COLUMN media_type TEXT NOT NULL DEFAULT 'photo'")
		except sqlite3.OperationalError:
			pass
		try:
			connection.execute("ALTER TABLE users ADD COLUMN language_code TEXT")
		except sqlite3.OperationalError:
			pass
		for column, definition in (("username", "TEXT NOT NULL DEFAULT ''"), ("display_name", "TEXT NOT NULL DEFAULT ''"), ("enabled", "INTEGER NOT NULL DEFAULT 1")):
			try:
				connection.execute(f"ALTER TABLE admins ADD COLUMN {column} {definition}")
			except sqlite3.OperationalError:
				pass
		connection.execute(
			"INSERT OR IGNORE INTO settings(name, value) VALUES ('margin_percent', ?)",
			(DEFAULT_MARGIN_PERCENT,),
		)
		connection.execute("INSERT OR IGNORE INTO settings(name, value) VALUES ('maintenance_mode', '0')")
		connection.execute("INSERT OR IGNORE INTO settings(name, value) VALUES ('notify_new_users', '0')")
		connection.execute("INSERT OR IGNORE INTO settings(name, value) VALUES ('notify_blocked_users', '0')")
		connection.execute("INSERT OR IGNORE INTO settings(name, value) VALUES ('notify_order_received', '1')")
		connection.execute("INSERT OR IGNORE INTO settings(name, value) VALUES ('notify_order_processing', '1')")
		connection.execute("INSERT OR IGNORE INTO settings(name, value) VALUES ('notify_order_completed', '1')")
		connection.execute("INSERT OR IGNORE INTO settings(name, value) VALUES ('notify_order_rejected', '1')")
		connection.execute("INSERT OR IGNORE INTO settings(name, value) VALUES ('completion_channel', '')")
		connection.execute("INSERT OR IGNORE INTO settings(name, value) VALUES ('stars_per_usd', '100')")
		connection.execute("INSERT OR IGNORE INTO settings(name, value) VALUES ('payment_stars_enabled', '1')")
		connection.execute("INSERT OR IGNORE INTO settings(name, value) VALUES ('payment_local_enabled', '1')")
		connection.execute("INSERT OR IGNORE INTO settings(name, value) VALUES ('payment_phone_enabled', '1')")
		connection.execute("INSERT OR IGNORE INTO settings(name, value) VALUES ('payment_bank_enabled', '1')")
		connection.execute("INSERT OR IGNORE INTO settings(name, value) VALUES ('payment_phone_details', 'أرسل المبلغ إلى رقم رصيد الهاتف ثم أرفق صورة التحويل ورقم العملية.')")
		connection.execute("INSERT OR IGNORE INTO settings(name, value) VALUES ('payment_bank_details', 'أرسل المبلغ إلى الحساب البنكي ثم أرفق إشعار التحويل ورقم العملية.')")
		try:
			connection.execute("ALTER TABLE orders ADD COLUMN notified_status TEXT")
		except sqlite3.OperationalError:
			pass
		for column, definition in (("payment_method", "TEXT NOT NULL DEFAULT 'local'"), ("stars", "INTEGER"), ("telegram_charge_id", "TEXT"), ("refunded_at", "TEXT"), ("refunded_by", "INTEGER")):
			try:
				connection.execute(f"ALTER TABLE deposits ADD COLUMN {column} {definition}")
			except sqlite3.OperationalError:
				pass
		connection.execute("CREATE UNIQUE INDEX IF NOT EXISTS deposits_telegram_charge_id ON deposits(telegram_charge_id) WHERE telegram_charge_id IS NOT NULL")
		for owner_id in CONFIG.owner_ids:
			connection.execute(
				"INSERT OR IGNORE INTO admins(telegram_id, username, display_name, role, permissions, enabled, created_at) VALUES (?, '', 'المالك', 'owner', 'all', 1, ?)",
				(owner_id, now()),
			)
		connection.commit()


def now() -> str:
	return datetime.now(timezone.utc).isoformat()


def register_user(user: Any) -> bool:
	with closing(db()) as connection:
		cursor = connection.execute(
			"INSERT OR IGNORE INTO users(telegram_id, username, first_name, language_code, created_at) VALUES (?, ?, ?, ?, ?)",
			(user.id, user.username or "", user.first_name or "", user.language_code or "", now()),
		)
		connection.execute(
			"UPDATE users SET username = ?, first_name = ?, language_code = ? WHERE telegram_id = ?",
			(user.username or "", user.first_name or "", user.language_code or "", user.id),
		)
		connection.commit()
	return cursor.rowcount == 1


def total_users() -> int:
	with closing(db()) as connection:
		return int(connection.execute("SELECT COUNT(*) AS count FROM users").fetchone()["count"])


def total_blocked() -> int:
	with closing(db()) as connection:
		return int(connection.execute("SELECT COUNT(*) AS count FROM blocked_users").fetchone()["count"])


def notification_enabled(name: str) -> bool:
	return text_setting(name, "0") == "1"


def formatted_time(value: str | None = None) -> str:
	try:
		return datetime.fromisoformat(value or now()).astimezone().strftime("%Y-%m-%d %H:%M:%S")
	except ValueError:
		return value or now()


async def notify_admins(bot: Any, message: str) -> None:
	for admin_id in permission_holders("notifications"):
		try:
			await bot.send_message(admin_id, message)
		except Exception:
			LOGGER.warning("Notification failed for admin %s", admin_id, exc_info=True)


async def notify_new_user(update: Update, user: Any) -> None:
	if notification_enabled("notify_new_users"):
		username = f"@{user.username}" if user.username else "لا يوجد"
		language = user.language_code or "غير محددة"
		await notify_admins(update.get_bot(), f"👾 شخص جديد دخل البوت\n\n👤 معلومات العضو الجديد:\n• الاسم: {user.full_name}\n• المعرف: {username}\n• الآيدي: {user.id}\n• 🌐 اللغة: {language}\n\n📊 إجمالي المستخدمين: {total_users()}")


async def my_chat_member(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
	change = update.my_chat_member
	if not change or not change.from_user or change.chat.type != "private":
		return
	user = change.from_user
	new_status = change.new_chat_member.status
	old_status = change.old_chat_member.status
	if new_status in {"kicked", "left"}:
		with closing(db()) as connection:
			connection.execute("INSERT OR REPLACE INTO blocked_users(telegram_id, username, first_name, language_code, blocked_at) VALUES (?, ?, ?, ?, ?)", (user.id, user.username or "", user.full_name, user.language_code or "", now()))
			connection.commit()
		if notification_enabled("notify_blocked_users") and old_status not in {"kicked", "left"}:
			username = f"@{user.username}" if user.username else "لا يوجد"
			language = user.language_code or "غير محددة"
			await notify_admins(update.get_bot(), f"🚫 قام أحد الأعضاء بحظر البوت الخاص بك\n\n👤 معلومات العضو:\n• الاسم: {user.full_name}\n• المعرّف: {username}\n• الآيدي: {user.id}\n• 🌐 اللغة: {language}\n\n📊 إجمالي الحظر: {total_blocked()}")
	elif new_status in {"member", "administrator", "creator"}:
		with closing(db()) as connection:
			connection.execute("DELETE FROM blocked_users WHERE telegram_id = ?", (user.id,))
			connection.commit()


def setting(name: str, default: float = 0) -> float:
	with closing(db()) as connection:
		row = connection.execute("SELECT value FROM settings WHERE name = ?", (name,)).fetchone()
	return float(row["value"]) if row else default


def text_setting(name: str, default: str = "") -> str:
	with closing(db()) as connection:
		row = connection.execute("SELECT value FROM settings WHERE name = ?", (name,)).fetchone()
	return str(row["value"]) if row else default


def save_setting(name: str, value: str) -> None:
	with closing(db()) as connection:
		connection.execute("INSERT OR REPLACE INTO settings(name, value) VALUES (?, ?)", (name, value))
		connection.commit()


def is_owner(telegram_id: int) -> bool:
	return telegram_id in CONFIG.owner_ids


def has_permission(telegram_id: int, permission: str) -> bool:
	if is_owner(telegram_id):
		return True
	with closing(db()) as connection:
		row = connection.execute("SELECT permissions FROM admins WHERE telegram_id = ? AND role = 'moderator' AND enabled = 1", (telegram_id,)).fetchone()
	if not row:
		return False
	return permission in {item.strip() for item in row["permissions"].split(",")}


def is_admin(telegram_id: int) -> bool:
	return is_owner(telegram_id) or has_permission(telegram_id, "support") or telegram_id in ADMIN_IDS


def permission_holders(permission: str) -> set[int]:
	with closing(db()) as connection:
		rows = connection.execute("SELECT telegram_id FROM admins WHERE role = 'moderator' AND enabled = 1 AND permissions LIKE ?", (f"%{permission}%",)).fetchall()
	return set(CONFIG.owner_ids) | {row["telegram_id"] for row in rows}


PERMISSIONS = {
	"deposits": "الشحن والمالية",
	"tutorials": "الخدمات والشروحات",
	"buttons": "الأزرار والمحتوى",
	"support": "الدعم ولوحة الإدارة",
	"broadcast": "الإذاعة",
	"notifications": "الإشعارات",
	"settings": "الإعدادات",
}


def admin_rows() -> list[sqlite3.Row]:
	with closing(db()) as connection:
		return connection.execute("SELECT * FROM admins WHERE role = 'moderator' ORDER BY created_at DESC").fetchall()


def permission_text(value: str) -> str:
	return ", ".join(PERMISSIONS.get(item, item) for item in value.split(",") if item)


def order_setting(name: str) -> bool:
	return text_setting(name, "1") == "1"


def provider_status_value(data: dict[str, Any]) -> str:
	value = str(data.get("status", "processing")).casefold().strip()
	if value in {"completed", "complete", "done", "finished", "مكتمل", "مكتملة"}:
		return "completed"
	if value in {"canceled", "cancelled", "cancel", "rejected", "refunded", "failed", "error", "ملغي", "مرفوض", "فشل"}:
		return "rejected"
	if value in {"in progress", "inprogress", "processing", "running", "جار التنفيذ", "قيد التنفيذ"}:
		return "processing"
	return "processing"


def masked_member_id(telegram_id: int) -> str:
	value = str(telegram_id)
	return f"••••••{value[-4:]}" if len(value) > 4 else value


async def send_order_notification(bot: Any, order: sqlite3.Row, status: str) -> None:
	if status == "received" and not order_setting("notify_order_received"):
		return
	if status == "processing" and not order_setting("notify_order_processing"):
		return
	if status == "completed" and not order_setting("notify_order_completed"):
		return
	if status == "rejected" and not order_setting("notify_order_rejected"):
		return
	order_id = order["provider_order_id"] or order["id"]
	if status == "received":
		message = f"✅| تم استلام طلبك : {order_id}\n💰| التكلفة: {money(order['cost'])}\n🆔| ايدي الطلب: {order_id}\n💎| نقاطك الحالية: {money(balance_of(order['telegram_id']))}\n🔎| لمعرفة حالة طلبك استخدم /status {order_id}"
	elif status == "processing":
		message = f"⚙️| بدأ تنفيذ طلبك : {order_id}\n🆔| ايدي الطلب: {order_id}\n🔎| يمكنك متابعة الحالة باستخدام /status {order_id}"
	elif status == "completed":
		message = f"✅ تم اكتمال طلبك بنجاح #{order_id}\n🧞‍♂️ نحن هنا لخدمتك دائمًا"
	else:
		message = f"❌ تعذر تنفيذ طلبك #{order_id}\n🧞‍♂️ تواصل مع الدعم لمعرفة التفاصيل"
	try:
		await bot.send_message(order["telegram_id"], message)
	except Exception:
		LOGGER.warning("Could not send order notification to %s", order["telegram_id"], exc_info=True)


async def publish_completed_order(bot: Any, order: sqlite3.Row) -> None:
	channel = text_setting("completion_channel", "")
	if not channel:
		return
	try:
		created = datetime.fromisoformat(order["created_at"]).astimezone().strftime("%a %b %d %H:%M:%S %Y")
	except ValueError:
		created = order["created_at"]
	message = f"📦| طلب جديد تم اكتماله ✅\n\n👤| العضو: ( {masked_member_id(order['telegram_id'])} )\n🗂️| الخدمة: {order['service_name']}\n♨️| الكمية: {order['quantity']}\n💎| التكلفة: {money(order['cost'])}\n⌚| الوقت: {created}\n🎁| مجاني: لا\n\n#🫱🏾‍🫲🏻| شكراً لاستخدامك بوت التمويل ✨"
	try:
		await bot.send_message(channel, message)
	except Exception:
		LOGGER.warning("Could not publish completed order %s", order["provider_order_id"], exc_info=True)


async def monitor_orders(context: ContextTypes.DEFAULT_TYPE) -> None:
	with closing(db()) as connection:
		orders = connection.execute("SELECT * FROM orders WHERE status IN ('pending', 'processing') AND provider_order_id IS NOT NULL ORDER BY id LIMIT 50").fetchall()
	for order in orders:
		try:
			provider_status = await provider.order_status(order["provider_order_id"])
			status = provider_status_value(provider_status)
			if status == order["status"] and order["notified_status"] == status:
				continue
			with closing(db()) as connection:
				connection.execute("UPDATE orders SET status = ?, notified_status = ? WHERE id = ?", (status, status, order["id"]))
				connection.commit()
			updated = dict(order)
			updated["status"] = status
			updated["notified_status"] = status
			updated_order = updated
			if status == "processing":
				await send_order_notification(context.bot, updated_order, "processing")
			elif status == "completed":
				await send_order_notification(context.bot, updated_order, "completed")
				await publish_completed_order(context.bot, updated_order)
			elif status == "rejected":
				await send_order_notification(context.bot, updated_order, "rejected")
		except Exception:
			LOGGER.warning("Order monitor failed for %s", order["provider_order_id"], exc_info=True)


def maintenance_enabled() -> bool:
	return text_setting("maintenance_mode", "0") == "1"


def service_hidden(service_id: str) -> bool:
	return text_setting(f"hidden_service:{service_id}", "0") == "1"


def local_services() -> list[Service]:
	with closing(db()) as connection:
		rows = connection.execute("SELECT * FROM local_services WHERE enabled = 1 ORDER BY name").fetchall()
	return [Service(
		service_id=str(row["service_id"]),
		name=str(row["name"]),
		category=str(row["category"]),
		provider_rate=float(row["provider_rate"]),
		minimum=int(row["minimum"]),
		maximum=int(row["maximum"]),
		refill=bool(row["refill"]),
	) for row in rows]


async def all_services() -> list[Service]:
	try:
		services = await provider.services()
	except Exception:
		LOGGER.exception("Could not load provider services")
		services = []
	by_id = {service.service_id: service for service in services}
	by_id.update({service.service_id: service for service in local_services()})
	return list(by_id.values())


def tutorial_for(service_id: str) -> sqlite3.Row | None:
	with closing(db()) as connection:
		return connection.execute("SELECT * FROM tutorials WHERE service_id = ?", (service_id,)).fetchone()


def custom_buttons() -> list[sqlite3.Row]:
	with closing(db()) as connection:
		return connection.execute("SELECT * FROM custom_buttons WHERE enabled = 1 ORDER BY position, id").fetchall()


def custom_button(button_id: str) -> sqlite3.Row | None:
	with closing(db()) as connection:
		return connection.execute("SELECT * FROM custom_buttons WHERE id = ? AND enabled = 1", (button_id,)).fetchone()


def any_custom_button(button_id: str) -> sqlite3.Row | None:
	with closing(db()) as connection:
		return connection.execute("SELECT * FROM custom_buttons WHERE id = ?", (button_id,)).fetchone()


BUTTON_COLORS = {"blue": "🔵", "green": "🟢", "red": "🔴", "yellow": "🟡", "purple": "🟣"}


def styled_label(label: str, color: str) -> str:
	return f"{BUTTON_COLORS.get(color, BUTTON_COLORS['blue'])} {label}"


def back_markup(target: str = "admin:content") -> InlineKeyboardMarkup:
	return InlineKeyboardMarkup([[InlineKeyboardButton("رجوع", callback_data=f"back:{target}")]])


def auto_reply_for(text: str) -> str | None:
	with closing(db()) as connection:
		rows = connection.execute("SELECT keyword, response FROM auto_replies WHERE enabled = 1").fetchall()
	for row in rows:
		if row["keyword"].casefold() in text.casefold():
			return row["response"]
	return None


def money(value: float) -> str:
	return f"{value:.2f} {CURRENCY}"


def stars_per_usd() -> float:
	return setting("stars_per_usd", 100)


def payment_enabled(method: str) -> bool:
	return text_setting(f"payment_{method}_enabled", "1") == "1"


def customer_price(service: Service, quantity: int) -> float:
	return service.provider_rate * quantity / 1000 * (1 + setting("margin_percent", 30) / 100)


def change_balance(telegram_id: int, amount: float) -> bool:
	with closing(db()) as connection:
		connection.execute("BEGIN IMMEDIATE")
		row = connection.execute("SELECT balance FROM users WHERE telegram_id = ?", (telegram_id,)).fetchone()
		if not row or row["balance"] + amount < -0.000001:
			connection.rollback()
			return False
		connection.execute("UPDATE users SET balance = balance + ? WHERE telegram_id = ?", (amount, telegram_id))
		connection.commit()
	return True


def balance_of(telegram_id: int) -> float:
	with closing(db()) as connection:
		row = connection.execute("SELECT balance FROM users WHERE telegram_id = ?", (telegram_id,)).fetchone()
	return float(row["balance"]) if row else 0


def menu() -> InlineKeyboardMarkup:
	rows = [
		[InlineKeyboardButton("الخدمات", callback_data="services"), InlineKeyboardButton("المحفظة", callback_data="wallet")],
		[InlineKeyboardButton("طلباتي", callback_data="orders"), InlineKeyboardButton("شحن الرصيد", callback_data="deposit")],
		[InlineKeyboardButton("المساعدة", callback_data="help")],
	]
	for button in custom_buttons():
		label = styled_label(button["label"], button["color"])
		rows.append([InlineKeyboardButton(label, url=button["url"]) if button["url"] else InlineKeyboardButton(label, callback_data=f"custom:{button['id']}")])
	return InlineKeyboardMarkup(rows)


def admin_menu() -> InlineKeyboardMarkup:
	return InlineKeyboardMarkup([
		[InlineKeyboardButton("الإعدادات", callback_data="admin:settings"), InlineKeyboardButton("إحصائيات", callback_data="admin:stats")],
		[InlineKeyboardButton("إدارة المحتوى", callback_data="admin:content"), InlineKeyboardButton("إدارة الخدمات", callback_data="admin:services")],
		[InlineKeyboardButton("الإشعارات", callback_data="admin:notifications"), InlineKeyboardButton("المالية", callback_data="admin:finance")],
		[InlineKeyboardButton("المشرفون", callback_data="admin:moderators")],
	])


def deposit_menu() -> InlineKeyboardMarkup:
	rows = []
	if payment_enabled("stars"):
		rows.append([InlineKeyboardButton("دفع بنجوم تيليجرام", callback_data="deposit_stars")])
	if payment_enabled("phone"):
		rows.append([InlineKeyboardButton("شحن عبر رصيد الهاتف", callback_data="deposit_phone")])
	if payment_enabled("bank"):
		rows.append([InlineKeyboardButton("تحويل بنكي", callback_data="deposit_bank")])
	rows.append([InlineKeyboardButton("رجوع", callback_data="back:user_menu")])
	return InlineKeyboardMarkup(rows)


def settings_menu(user_id: int) -> InlineKeyboardMarkup:
	rows = [
		[InlineKeyboardButton("تعديل نسبة الربح", callback_data="admin:set_margin"), InlineKeyboardButton("وضع الصيانة", callback_data="admin:toggle_maintenance")],
		[InlineKeyboardButton("تعديل الترحيب", callback_data="admin:set_welcome"), InlineKeyboardButton("تحديث API", callback_data="admin:set_api")],
		[InlineKeyboardButton("القناة الإجبارية", callback_data="admin:set_force_subscribe")],
		[InlineKeyboardButton("إشعار الدخول", callback_data="admin:notify_new"), InlineKeyboardButton("إشعار الحظر", callback_data="admin:notify_blocked")],
		[InlineKeyboardButton("رجوع", callback_data="admin:home")],
	]
	return InlineKeyboardMarkup(rows)


def notifications_menu() -> InlineKeyboardMarkup:
	new_label = "إيقاف إشعار الدخول" if notification_enabled("notify_new_users") else "تفعيل إشعار الدخول"
	blocked_label = "إيقاف إشعار الحظر" if notification_enabled("notify_blocked_users") else "تفعيل إشعار الحظر"
	return InlineKeyboardMarkup([
		[InlineKeyboardButton(new_label, callback_data="admin:notify_new"), InlineKeyboardButton(blocked_label, callback_data="admin:notify_blocked")],
		[InlineKeyboardButton("إشعارات الطلبات", callback_data="admin:order_notifications")],
		[InlineKeyboardButton("تحديث العدادات", callback_data="admin:notification_stats")],
		[InlineKeyboardButton("رجوع", callback_data="admin:home")],
	])


def order_notifications_menu() -> InlineKeyboardMarkup:
	labels = {
		"notify_order_received": "الاستلام",
		"notify_order_processing": "بدء التنفيذ",
		"notify_order_completed": "الاكتمال",
		"notify_order_rejected": "الرفض",
	}
	rows = []
	for name, label in labels.items():
		state = "✅" if order_setting(name) else "❌"
		rows.append([InlineKeyboardButton(f"{state} إشعار {label}", callback_data=f"admin:order_notify:{name}")])
	rows.append([InlineKeyboardButton("تعيين قناة الإكمال", callback_data="admin:completion_channel")])
	rows.append([InlineKeyboardButton("رجوع", callback_data="admin:notifications")])
	return InlineKeyboardMarkup(rows)


def moderators_menu() -> InlineKeyboardMarkup:
	return InlineKeyboardMarkup([
		[InlineKeyboardButton("إضافة مشرف", callback_data="moderator:add")],
		[InlineKeyboardButton("قائمة المشرفين", callback_data="moderator:list")],
		[InlineKeyboardButton("رجوع", callback_data="admin:home")],
	])


def moderator_editor_menu(telegram_id: int, permissions: str) -> InlineKeyboardMarkup:
	rows = []
	active = {item.strip() for item in permissions.split(",") if item.strip()}
	items = list(PERMISSIONS.items())
	for index in range(0, len(items), 2):
		row = []
		for key, label in items[index:index + 2]:
			mark = "✅" if key in active else "⬜"
			row.append(InlineKeyboardButton(f"{mark} {label}", callback_data=f"moderator:perm:{telegram_id}:{key}"))
		rows.append(row)
	rows.extend([
		[InlineKeyboardButton("تفعيل/إيقاف", callback_data=f"moderator:toggle:{telegram_id}"), InlineKeyboardButton("حذف", callback_data=f"moderator:delete:{telegram_id}")],
		[InlineKeyboardButton("رجوع", callback_data="moderator:list")],
	])
	return InlineKeyboardMarkup(rows)


def content_menu() -> InlineKeyboardMarkup:
	return InlineKeyboardMarkup([
		[InlineKeyboardButton("إنشاء زر رابط", callback_data="content:create_url"), InlineKeyboardButton("إنشاء زر محتوى", callback_data="content:create_content")],
		[InlineKeyboardButton("إنشاء زر تواصل", callback_data="content:create_contact"), InlineKeyboardButton("الردود التلقائية", callback_data="content:reply")],
		[InlineKeyboardButton("إخفاء/إظهار خدمة", callback_data="content:visibility"), InlineKeyboardButton("قائمة الأزرار", callback_data="content:list")],
		[InlineKeyboardButton("رجوع", callback_data="admin:home")],
	])


def button_editor_menu(button_id: int) -> InlineKeyboardMarkup:
	return InlineKeyboardMarkup([
		[InlineKeyboardButton("تعديل الاسم", callback_data=f"button:edit_label:{button_id}"), InlineKeyboardButton("محتوى الزر", callback_data=f"button:edit_content:{button_id}")],
		[InlineKeyboardButton("إعدادات الرد", callback_data=f"button:edit_reply:{button_id}"), InlineKeyboardButton("تغيير النوع", callback_data=f"button:type:{button_id}")],
		[InlineKeyboardButton("تغيير المظهر", callback_data=f"button:color:{button_id}"), InlineKeyboardButton("التنبيه", callback_data=f"button:alert:{button_id}")],
		[InlineKeyboardButton("تفعيل/إيقاف", callback_data=f"button:toggle:{button_id}"), InlineKeyboardButton("إحصائيات", callback_data=f"button:stats:{button_id}")],
		[InlineKeyboardButton("نقل الزر", callback_data=f"button:move:{button_id}"), InlineKeyboardButton("حذف الزر", callback_data=f"button:delete:{button_id}")],
		[InlineKeyboardButton("رجوع", callback_data="content:list")],
	])


def color_menu(button_id: int) -> InlineKeyboardMarkup:
	return InlineKeyboardMarkup([[InlineKeyboardButton(f"{icon} {name}", callback_data=f"button:setcolor:{button_id}:{key}") for key, (name, icon) in {"blue": ("أزرق", "🔵"), "green": ("أخضر", "🟢"), "red": ("أحمر", "🔴")}.items()], [InlineKeyboardButton("🟡 أصفر", callback_data=f"button:setcolor:{button_id}:yellow"), InlineKeyboardButton("🟣 بنفسجي", callback_data=f"button:setcolor:{button_id}:purple")], [InlineKeyboardButton("رجوع", callback_data=f"button:edit:{button_id}")]])


def services_admin_menu() -> InlineKeyboardMarkup:
	return InlineKeyboardMarkup([
		[InlineKeyboardButton("إضافة خدمة جديدة", callback_data="admin:add_service")],
		[InlineKeyboardButton("شرح نصي لخدمة", callback_data="admin:tutorial_text"), InlineKeyboardButton("شرح بصورة/فيديو", callback_data="admin:tutorial_media")],
		[InlineKeyboardButton("إخفاء أو إظهار خدمة", callback_data="content:visibility")],
		[InlineKeyboardButton("رجوع", callback_data="admin:home")],
	])


async def start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
	user = update.effective_user
	if not user or not update.message:
		return
	if register_user(user):
		await notify_new_user(update, user)
	if maintenance_enabled() and not is_admin(user.id):
		await update.message.reply_text("البوت في وضع الصيانة حالياً. حاول لاحقاً.")
		return
	if not await subscribed(update, user.id):
		return
	welcome = text_setting("welcome_text", f"أهلاً {user.first_name} في بوت التمويل.")
	await update.message.reply_text(
		f"{welcome}\nرصيدك الحالي: {money(balance_of(user.id))}",
		reply_markup=menu(),
	)


async def subscribed(update: Update, user_id: int) -> bool:
	channel = text_setting("force_subscribe_channel", CONFIG.force_subscribe_channel)
	if not channel or is_admin(user_id):
		return True
	try:
		member = await update.get_bot().get_chat_member(channel, user_id)
		if member.status in {"creator", "administrator", "member"}:
			return True
	except Exception:
		LOGGER.warning("Force subscription check failed", exc_info=True)
	await update.effective_message.reply_text(f"يجب الاشتراك في القناة {channel} أولاً ثم إرسال /start مرة أخرى.")
	return False


async def services_message(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
	services = await all_services()
	service_cache.clear()
	service_cache.update({service.service_id: service for service in services})
	if not services:
		await update.effective_message.reply_text("لا توجد خدمات متاحة حالياً.", reply_markup=menu())
		return
	categories = sorted({service.category for service in services})
	buttons = [[InlineKeyboardButton(category, callback_data=f"category:{category}")] for category in categories]
	message = "اختر القسم:"
	if any(category.startswith("تيليجرام -") for category in categories):
		message += "\nتمت إضافة خدمات القنوات والقروبات والمشاهدات والتفاعل حسب المتاح من المزود."
	await update.effective_message.reply_text(message, reply_markup=InlineKeyboardMarkup(buttons))


async def callback(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
	query = update.callback_query
	if not query or not query.from_user:
		return
	register_user(query.from_user)
	if not await subscribed(update, query.from_user.id):
		return
	if maintenance_enabled() and not is_admin(query.from_user.id):
		await query.edit_message_text("البوت في وضع الصيانة حالياً. حاول لاحقاً.")
		return
	data = query.data or ""
	if not data.startswith("custom:"):
		await query.answer()
	if data.startswith("back:"):
		context.user_data.clear()
		target = data.split(":", 1)[1]
		if target == "admin:home":
			await query.edit_message_text("لوحة التحكم الرئيسية", reply_markup=admin_menu())
		elif target == "admin:settings":
			await query.edit_message_text("إعدادات البوت", reply_markup=settings_menu(query.from_user.id))
		elif target.startswith("button:edit:"):
			button_id = target.rsplit(":", 1)[1]
			button = any_custom_button(button_id)
			if button:
				await query.edit_message_text(f"تحرير الزر: {button['label']}", reply_markup=button_editor_menu(int(button_id)))
		elif target == "admin:content":
			await query.edit_message_text("إدارة الأزرار والردود", reply_markup=content_menu())
		elif target == "admin:finance":
			await query.edit_message_text("إدارة المالية", reply_markup=admin_menu())
		elif target == "user_menu":
			await query.edit_message_text("القائمة الرئيسية", reply_markup=menu())
		return
	if data == "services":
		await services_message(update, context)
	elif data == "wallet":
		await query.edit_message_text(f"رصيدك الحالي: {money(balance_of(query.from_user.id))}", reply_markup=menu())
	elif data == "help":
		support = f"\nالدعم: @{SUPPORT_USERNAME}" if SUPPORT_USERNAME else ""
		await query.edit_message_text("اختر الخدمة ثم أرسل الرابط والكمية. للشحن أرسل المبلغ وإثبات التحويل." + support, reply_markup=menu())
	elif data == "deposit":
		await query.edit_message_text(f"اختر طريقة شحن المحفظة:\nسعر التحويل الحالي: كل {stars_per_usd():g} نجمة = 1 دولار", reply_markup=deposit_menu())
	elif data == "deposit_stars":
		if not payment_enabled("stars"):
			await query.edit_message_text("الدفع بالنجوم غير متاح حالياً.", reply_markup=deposit_menu())
			return
		context.user_data["state"] = "stars_amount"
		await query.edit_message_text("أرسل المبلغ بالدولار الذي تريد إضافته، مثال: 1 أو 5:", reply_markup=back_markup("user_menu"))
	elif data in {"deposit_phone", "deposit_bank"}:
		method = "phone" if data == "deposit_phone" else "bank"
		if not payment_enabled(method):
			await query.edit_message_text("طريقة الدفع غير متاحة حالياً.", reply_markup=deposit_menu())
			return
		context.user_data.update(state="deposit", deposit_method=method)
		label = "رصيد الهاتف" if method == "phone" else "التحويل البنكي"
		await query.edit_message_text(f"طريقة الدفع: {label}\n\n{text_setting(f'payment_{method}_details')}\n\nأرسل المبلغ ثم رقم العملية أو صورة التحويل مع كتابة المبلغ في الوصف.", reply_markup=back_markup("user_menu"))
	elif data == "orders":
		with closing(db()) as connection:
			rows = connection.execute("SELECT provider_order_id, service_name, cost, status FROM orders WHERE telegram_id = ? ORDER BY id DESC LIMIT 10", (query.from_user.id,)).fetchall()
		text = "\n".join(f"#{row['provider_order_id'] or '-'} | {row['service_name']} | {money(row['cost'])} | {row['status']}" for row in rows) or "لا توجد طلبات بعد."
		await query.edit_message_text(text, reply_markup=menu())
	elif data.startswith("category:"):
		category = data.split(":", 1)[1]
		buttons = [[InlineKeyboardButton(f"{service.name} | من {service.minimum} إلى {service.maximum}", callback_data=f"service:{service.service_id}")] for service in service_cache.values() if service.category == category and not service_hidden(service.service_id)]
		buttons.append([InlineKeyboardButton("رجوع", callback_data="back:user_menu")])
		await query.edit_message_text("اختر الخدمة:", reply_markup=InlineKeyboardMarkup(buttons))
	elif data.startswith("service:"):
		service_id = data.split(":", 1)[1]
		if service_id not in service_cache:
			await query.edit_message_text("انتهت صلاحية القائمة، أعد فتح الخدمات.", reply_markup=menu())
			return
		if service_hidden(service_id):
			await query.edit_message_text("هذه الخدمة متوقفة مؤقتاً.", reply_markup=back_markup("user_menu"))
			return
		context.user_data.update(state="link", service_id=service_id)
		tutorial = tutorial_for(service_id)
		if tutorial and tutorial["content"]:
			instruction = f"تعليمات الخدمة:\n\n{tutorial['content']}\n\nأرسل رابط الحساب أو المنشور المطلوب:"
			if tutorial["photo_file_id"] and tutorial["media_type"] == "video":
				await query.message.reply_video(tutorial["photo_file_id"], caption=instruction)
				await query.edit_message_text("تم إرسال الشرح، أرسل رابط الحساب أو المنشور المطلوب:", reply_markup=back_markup("user_menu"))
			elif tutorial["photo_file_id"]:
				await query.message.reply_photo(tutorial["photo_file_id"], caption=instruction)
				await query.edit_message_text("تم إرسال الشرح، أرسل رابط الحساب أو المنشور المطلوب:", reply_markup=back_markup("user_menu"))
			else:
				await query.edit_message_text(instruction, reply_markup=back_markup("user_menu"))
		else:
			await query.edit_message_text("أرسل رابط الحساب أو المنشور المطلوب:", reply_markup=back_markup("user_menu"))
	elif data == "admin:stats" and is_admin(query.from_user.id):
		with closing(db()) as connection:
			users = connection.execute("SELECT COUNT(*) AS count FROM users").fetchone()["count"]
			orders = connection.execute("SELECT COUNT(*) AS count, COALESCE(SUM(cost), 0) AS revenue FROM orders").fetchone()
		await query.edit_message_text(f"المستخدمون: {users}\nالمحظورون: {total_blocked()}\nالطلبات: {orders['count']}\nإجمالي المبيعات: {money(orders['revenue'])}\nالهامش: {setting('margin_percent')}%", reply_markup=admin_menu())
	elif data == "admin:settings" and is_admin(query.from_user.id):
		maintenance = "مفعّل" if maintenance_enabled() else "متوقف"
		channel = text_setting("force_subscribe_channel", CONFIG.force_subscribe_channel)
		new_users = "مفعّل" if notification_enabled("notify_new_users") else "متوقف"
		blocked = "مفعّل" if notification_enabled("notify_blocked_users") else "متوقف"
		await query.edit_message_text(f"إعدادات البوت\n\nنسبة الربح: {setting('margin_percent')}%\nالصيانة: {maintenance}\nالقناة الإجبارية: {channel or 'غير مفعلة'}\nإشعار الدخول: {new_users}\nإشعار الحظر: {blocked}", reply_markup=settings_menu(query.from_user.id))
	elif data == "admin:notifications" and is_admin(query.from_user.id):
		await query.edit_message_text("قسم الإشعارات\n\n🔔 إشعار الدخول: يرسل تنبيهاً عند دخول مستخدم جديد لأول مرة.\n🚫 إشعار الحظر: يرسل تنبيهاً عند حظر المستخدم للبوت.\n📦 إشعارات الطلبات: ترسل للعميل عند الاستلام والتنفيذ والاكتمال والرفض.", reply_markup=notifications_menu())
	elif data == "admin:order_notifications" and is_admin(query.from_user.id):
		await query.edit_message_text("إشعارات الطلبات\n\nيمكنك تشغيل أو إيقاف كل مرحلة بشكل مستقل.", reply_markup=order_notifications_menu())
	elif data == "admin:home" and is_admin(query.from_user.id):
		await query.edit_message_text("لوحة التحكم الرئيسية", reply_markup=admin_menu())
	elif data == "admin:set_margin" and has_permission(query.from_user.id, "settings"):
		context.user_data["state"] = "margin"
		await query.edit_message_text("أرسل نسبة الربح الجديدة، مثال: 35", reply_markup=back_markup("admin:settings"))
	elif data == "admin:toggle_maintenance" and is_owner(query.from_user.id):
		enabled = not maintenance_enabled()
		save_setting("maintenance_mode", "1" if enabled else "0")
		await query.edit_message_text(f"تم {'تفعيل' if enabled else 'إيقاف'} وضع الصيانة.", reply_markup=settings_menu(query.from_user.id))
	elif data == "admin:set_welcome" and is_owner(query.from_user.id):
		context.user_data["state"] = "welcome"
		await query.edit_message_text("أرسل رسالة الترحيب الجديدة:", reply_markup=back_markup("admin:settings"))
	elif data == "admin:set_api" and is_owner(query.from_user.id):
		context.user_data["state"] = "api_key"
		await query.edit_message_text("أرسل مفتاح API الجديد. لن يتم عرضه في الرسائل اللاحقة:", reply_markup=back_markup("admin:settings"))
	elif data == "admin:set_force_subscribe" and is_owner(query.from_user.id):
		context.user_data["state"] = "force_subscribe"
		await query.edit_message_text("أرسل معرف القناة مثل @mychannel، أو off لإلغاء الاشتراك الإجباري:", reply_markup=back_markup("admin:settings"))
	elif data in {"admin:notify_new", "admin:notify_blocked"} and is_owner(query.from_user.id):
		setting_name = "notify_new_users" if data == "admin:notify_new" else "notify_blocked_users"
		enabled = not notification_enabled(setting_name)
		save_setting(setting_name, "1" if enabled else "0")
		label = "إشعار الدخول" if setting_name == "notify_new_users" else "إشعار الحظر"
		await query.edit_message_text(f"{label}: {'مفعّل' if enabled else 'متوقف'}", reply_markup=notifications_menu())
	elif data == "admin:notification_stats" and is_admin(query.from_user.id):
		await query.edit_message_text(f"📊 إحصائيات الإشعارات\n\nإجمالي المستخدمين: {total_users()}\nإجمالي الحظر: {total_blocked()}", reply_markup=notifications_menu())
	elif data.startswith("admin:order_notify:") and is_owner(query.from_user.id):
		name = data.rsplit(":", 1)[1]
		save_setting(name, "0" if order_setting(name) else "1")
		await query.edit_message_text("تم تحديث إعداد إشعار الطلب.", reply_markup=order_notifications_menu())
	elif data == "admin:completion_channel" and is_owner(query.from_user.id):
		context.user_data["state"] = "completion_channel"
		await query.edit_message_text("أرسل معرف قناة الإكمال مثل @completed_orders أو off لإلغاء النشر.", reply_markup=back_markup("admin:order_notifications"))
	elif data == "admin:tutorial" and has_permission(query.from_user.id, "tutorials"):
		context.user_data["state"] = "tutorial"
		await query.edit_message_text("أرسل: رقم_الخدمة | نص التعليمات\nمثال: 15 | يجب أن يكون الحساب عاماً.", reply_markup=back_markup("admin:home"))
	elif data == "admin:content" and has_permission(query.from_user.id, "buttons"):
		await query.edit_message_text("إدارة الأزرار والردود\n\nاختر نوع المحتوى الذي تريد إنشاءه:", reply_markup=content_menu())
	elif data == "admin:services" and has_permission(query.from_user.id, "tutorials"):
		await query.edit_message_text("إدارة الخدمات والشروحات\n\nاختر نوع الشرح أو التحكم بظهور الخدمة:", reply_markup=services_admin_menu())
	elif data == "admin:add_service" and has_permission(query.from_user.id, "tutorials"):
		context.user_data.update(state="local_service_id", local_service={})
		await query.edit_message_text("أرسل رقم الخدمة لدى المزود (Service ID):", reply_markup=back_markup("admin:services"))
	elif data == "admin:tutorial_text" and has_permission(query.from_user.id, "tutorials"):
		context.user_data["state"] = "tutorial"
		await query.edit_message_text("أرسل: رقم_الخدمة | نص التعليمات", reply_markup=back_markup("admin:home"))
	elif data == "admin:tutorial_media" and has_permission(query.from_user.id, "tutorials"):
		context.user_data["state"] = "tutorial"
		await query.edit_message_text("أرسل صورة أو فيديو، واكتب في الوصف: رقم_الخدمة | نص التعليمات", reply_markup=back_markup("admin:home"))
	elif data.startswith("content:create_") and has_permission(query.from_user.id, "buttons"):
		button_type = data.removeprefix("content:create_")
		context.user_data.update(state="button_label", button_type=button_type)
		await query.edit_message_text("أرسل اسم الزر الذي سيظهر للمستخدمين:", reply_markup=back_markup("admin:content"))
	elif data == "content:reply" and has_permission(query.from_user.id, "buttons"):
		context.user_data["state"] = "reply_keyword"
		await query.edit_message_text("أرسل الكلمة المفتاحية للرد التلقائي:", reply_markup=back_markup("admin:content"))
	elif data == "content:visibility" and has_permission(query.from_user.id, "buttons"):
		context.user_data["state"] = "visibility"
		await query.edit_message_text("أرسل: hide رقم_الخدمة أو show رقم_الخدمة", reply_markup=back_markup("admin:content"))
	elif data == "content:list" and has_permission(query.from_user.id, "buttons"):
		with closing(db()) as connection:
			buttons = connection.execute("SELECT id, label, button_type, enabled, clicks, position FROM custom_buttons ORDER BY position, id").fetchall()
		rows = [[InlineKeyboardButton(f"تعديل: {button['label']}", callback_data=f"button:edit:{button['id']}")] for button in buttons]
		rows.append([InlineKeyboardButton("رجوع", callback_data="admin:content")])
		text = "إدارة الأزرار:\n" + "\n".join(f"#{button['id']} {button['label']} | {button['button_type']} | {'مفعّل' if button['enabled'] else 'متوقف'} | ضغطات: {button['clicks']}" for button in buttons) if buttons else "لا توجد أزرار مخصصة بعد."
		await query.edit_message_text(text, reply_markup=InlineKeyboardMarkup(rows))
	elif data.startswith("button:") and has_permission(query.from_user.id, "buttons"):
		parts = data.split(":")
		action = parts[1]
		button_id = parts[2] if len(parts) > 2 else ""
		button = any_custom_button(button_id) if action != "edit" else None
		if action == "edit":
			with closing(db()) as connection:
				button = connection.execute("SELECT * FROM custom_buttons WHERE id = ?", (button_id,)).fetchone()
			if button:
				await query.edit_message_text(f"تحرير الزر: {button['label']}\nالنوع: {button['button_type']}\nالحالة: {'مفعّل' if button['enabled'] else 'متوقف'}\nالضغطات: {button['clicks']}", reply_markup=button_editor_menu(int(button_id)))
		elif not button:
			await query.edit_message_text("الزر غير موجود.", reply_markup=content_menu())
		elif action in {"edit_label", "edit_content", "edit_reply", "type", "move"}:
			state = {"edit_label": "button_edit_label", "edit_content": "button_edit_content", "edit_reply": "button_edit_reply", "type": "button_edit_type", "move": "button_move"}[action]
			context.user_data.update(state=state, button_id=button_id)
			prompt = {"button_edit_label": "أرسل الاسم الجديد:", "button_edit_content": "أرسل محتوى الزر الجديد أو رابطاً إذا كان نوعه رابطاً:", "button_edit_reply": "أرسل الرد الجديد:", "button_edit_type": "أرسل النوع: url أو content أو contact:", "button_move": "أرسل رقم الموضع الجديد (1، 2، 3...):"}[state]
			await query.edit_message_text(prompt, reply_markup=back_markup(f"button:edit:{button_id}"))
		elif action == "color":
			await query.edit_message_text("اختر لون مظهر الزر:", reply_markup=color_menu(int(button_id)))
		elif action == "setcolor":
			color = parts[3] if len(parts) > 3 else "blue"
			with closing(db()) as connection:
				connection.execute("UPDATE custom_buttons SET color = ? WHERE id = ?", (color, button_id))
				connection.commit()
			await query.edit_message_text("تم تغيير مظهر الزر.", reply_markup=button_editor_menu(int(button_id)))
		elif action == "toggle":
			with closing(db()) as connection:
				connection.execute("UPDATE custom_buttons SET enabled = CASE enabled WHEN 1 THEN 0 ELSE 1 END WHERE id = ?", (button_id,))
				connection.commit()
			await query.edit_message_text("تم تبديل حالة الزر.", reply_markup=button_editor_menu(int(button_id)))
		elif action == "alert":
			with closing(db()) as connection:
				connection.execute("UPDATE custom_buttons SET alert = CASE alert WHEN 1 THEN 0 ELSE 1 END WHERE id = ?", (button_id,))
				connection.commit()
			await query.edit_message_text("تم تبديل تنبيه الزر.", reply_markup=button_editor_menu(int(button_id)))
		elif action == "stats":
			with closing(db()) as connection:
				stats = connection.execute("SELECT clicks, enabled, position FROM custom_buttons WHERE id = ?", (button_id,)).fetchone()
			await query.edit_message_text(f"إحصائيات الزر\nالضغطات المباشرة: {stats['clicks']}\nالحالة: {'مفعّل' if stats['enabled'] else 'متوقف'}\nالموضع: {stats['position']}\n\nملاحظة: أزرار الروابط الخارجية لا ترسل إشعار ضغط للبوت.", reply_markup=button_editor_menu(int(button_id)))
		elif action == "delete":
			await query.edit_message_text("تنبيه: هل تريد حذف الزر نهائياً؟", reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("نعم، احذف", callback_data=f"button:confirm_delete:{button_id}"), InlineKeyboardButton("إلغاء", callback_data=f"button:edit:{button_id}")]]))
		elif action == "confirm_delete":
			with closing(db()) as connection:
				connection.execute("DELETE FROM custom_buttons WHERE id = ?", (button_id,))
				connection.commit()
			await query.edit_message_text("تم حذف الزر نهائياً.", reply_markup=content_menu())
	elif data == "admin:moderators" and is_owner(query.from_user.id):
		await query.edit_message_text("إدارة المشرفين\n\nيمكنك إضافة المشرف بالآيدي أو بمعرف المستخدم، ثم تحديد صلاحياته من القائمة.", reply_markup=moderators_menu())
	elif data == "moderator:add" and is_owner(query.from_user.id):
		context.user_data["state"] = "moderator_identity"
		await query.edit_message_text("أرسل آيدي المستخدم مثل 123456789 أو معرفه مثل @username:", reply_markup=back_markup("admin:moderators"))
	elif data == "moderator:list" and is_owner(query.from_user.id):
		rows = [[InlineKeyboardButton(f"{'🟢' if row['enabled'] else '🔴'} {row['display_name'] or row['username'] or row['telegram_id']}", callback_data=f"moderator:edit:{row['telegram_id']}")] for row in admin_rows()]
		rows.append([InlineKeyboardButton("إضافة مشرف", callback_data="moderator:add"), InlineKeyboardButton("رجوع", callback_data="admin:moderators")])
		text = "المشرفون الحاليون:\n\n" + "\n".join(f"#{row['telegram_id']} | {row['username'] or 'بدون معرف'} | {'مفعّل' if row['enabled'] else 'متوقف'}" for row in admin_rows()) if admin_rows() else "لا يوجد مشرفون إضافيون."
		await query.edit_message_text(text, reply_markup=InlineKeyboardMarkup(rows))
	elif data.startswith("moderator:") and is_owner(query.from_user.id):
		parts = data.split(":")
		action = parts[1]
		moderator_id = parts[2] if len(parts) > 2 else ""
		with closing(db()) as connection:
			moderator = connection.execute("SELECT * FROM admins WHERE telegram_id = ? AND role = 'moderator'", (moderator_id,)).fetchone()
		if action == "edit" and moderator:
			await query.edit_message_text(f"تحرير المشرف\n\nالاسم: {moderator['display_name'] or 'غير معروف'}\nالمعرف: {moderator['username'] or 'لا يوجد'}\nالآيدي: {moderator['telegram_id']}\nالحالة: {'مفعّل' if moderator['enabled'] else 'متوقف'}\nالصلاحيات: {permission_text(moderator['permissions'])}", reply_markup=moderator_editor_menu(int(moderator_id), moderator['permissions']))
		elif action == "perm" and moderator and len(parts) > 3:
			permission = parts[3]
			permissions = {item.strip() for item in moderator['permissions'].split(',') if item.strip()}
			if permission in permissions:
				permissions.remove(permission)
			else:
				permissions.add(permission)
			with closing(db()) as connection:
				connection.execute("UPDATE admins SET permissions = ? WHERE telegram_id = ? AND role = 'moderator'", (",".join(sorted(permissions)), moderator_id))
				connection.commit()
			await query.edit_message_text("تم تحديث الصلاحيات.", reply_markup=moderator_editor_menu(int(moderator_id), ",".join(sorted(permissions))))
		elif action == "toggle" and moderator:
			with closing(db()) as connection:
				connection.execute("UPDATE admins SET enabled = CASE enabled WHEN 1 THEN 0 ELSE 1 END WHERE telegram_id = ?", (moderator_id,))
				connection.commit()
			await query.edit_message_text("تم تحديث حالة المشرف.", reply_markup=moderators_menu())
		elif action == "delete" and moderator:
			await query.edit_message_text("هل تريد حذف هذا المشرف؟", reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("نعم، حذف", callback_data=f"moderator:confirm_delete:{moderator_id}"), InlineKeyboardButton("إلغاء", callback_data=f"moderator:edit:{moderator_id}")]]))
		elif action == "confirm_delete":
			with closing(db()) as connection:
				connection.execute("DELETE FROM admins WHERE telegram_id = ? AND role = 'moderator'", (moderator_id,))
				connection.commit()
			await query.edit_message_text("تم حذف المشرف.", reply_markup=moderators_menu())
	elif data == "admin:finance" and has_permission(query.from_user.id, "deposits"):
		with closing(db()) as connection:
			deposits = connection.execute("SELECT COUNT(*) AS count, COALESCE(SUM(amount), 0) AS total FROM deposits WHERE status = 'approved'").fetchone()
			profit = connection.execute("SELECT COALESCE(SUM(cost), 0) AS total FROM orders").fetchone()["total"]
		stars_label = "إيقاف الدفع بالنجوم" if payment_enabled("stars") else "تفعيل الدفع بالنجوم"
		phone_label = "إيقاف رصيد الهاتف" if payment_enabled("phone") else "تفعيل رصيد الهاتف"
		bank_label = "إيقاف التحويل البنكي" if payment_enabled("bank") else "تفعيل التحويل البنكي"
		await query.edit_message_text(f"الإيداعات المقبولة: {deposits['count']}\nمجموع الإيداعات: {money(deposits['total'])}\nمبيعات الطلبات: {money(profit)}\nسعر النجوم: كل {stars_per_usd():g} نجمة = 1 دولار", reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("تعديل سعر النجوم", callback_data="admin:stars_rate")], [InlineKeyboardButton(stars_label, callback_data="admin:toggle_payment:stars")], [InlineKeyboardButton(phone_label, callback_data="admin:toggle_payment:phone")], [InlineKeyboardButton(bank_label, callback_data="admin:toggle_payment:bank")], [InlineKeyboardButton("بيانات الدفع المحلي", callback_data="admin:payment_details")], [InlineKeyboardButton("شحن مستخدم عبر الآيدي", callback_data="admin:credit_user")], [InlineKeyboardButton("استرداد دفعة نجوم", callback_data="admin:refund_stars")], [InlineKeyboardButton("رجوع", callback_data="admin:home")]]))
	elif data == "admin:stars_rate" and has_permission(query.from_user.id, "deposits"):
		context.user_data["state"] = "stars_rate"
		await query.edit_message_text("أرسل عدد النجوم الذي يساوي دولاراً واحداً، مثال: 100:", reply_markup=back_markup("admin:home"))
	elif data == "admin:refund_stars" and has_permission(query.from_user.id, "deposits"):
		context.user_data["state"] = "refund_stars"
		await query.edit_message_text("أرسل رمز عملية الدفع الذي تريد استرداده:", reply_markup=back_markup("admin:home"))
	elif data == "admin:payment_details" and has_permission(query.from_user.id, "deposits"):
		await query.edit_message_text("اختر بيانات الطريقة التي تريد تعديلها:", reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("بيانات رصيد الهاتف", callback_data="admin:payment_details:phone")], [InlineKeyboardButton("بيانات التحويل البنكي", callback_data="admin:payment_details:bank")], [InlineKeyboardButton("رجوع", callback_data="admin:finance")]]))
	elif data.startswith("admin:payment_details:") and has_permission(query.from_user.id, "deposits"):
		method = data.rsplit(":", 1)[1]
		if method not in {"phone", "bank"}:
			return
		context.user_data["state"] = f"payment_details_{method}"
		await query.edit_message_text(f"أرسل بيانات الدفع الجديدة لـ {'رصيد الهاتف' if method == 'phone' else 'التحويل البنكي'}:", reply_markup=back_markup("admin:finance"))
	elif data == "admin:credit_user" and has_permission(query.from_user.id, "deposits"):
		context.user_data["state"] = "admin_credit_id"
		await query.edit_message_text("أرسل آيدي المستخدم الذي تريد شحنه:", reply_markup=back_markup("admin:finance"))
	elif data.startswith("admin:toggle_payment:") and has_permission(query.from_user.id, "deposits"):
		method = data.rsplit(":", 1)[1]
		if method not in {"stars", "phone", "bank"}:
			return
		enabled = not payment_enabled(method)
		save_setting(f"payment_{method}_enabled", "1" if enabled else "0")
		await query.edit_message_text(f"تم {'تفعيل' if enabled else 'إيقاف'} طريقة الدفع.", reply_markup=admin_menu())
	elif data == "admin:margin" and has_permission(query.from_user.id, "settings"):
		context.user_data["state"] = "margin"
		await query.edit_message_text("أرسل نسبة الهامش الجديدة، مثال: 35")
	elif data == "admin:provider_balance" and has_permission(query.from_user.id, "settings"):
		try:
			value = await provider.balance()
			await query.edit_message_text(f"رصيد المزود: {money(value)}", reply_markup=admin_menu())
		except Exception as exc:
			await query.edit_message_text(f"تعذر قراءة رصيد المزود: {exc}", reply_markup=admin_menu())
	elif data.startswith("custom:"):
		button_id = data.split(":", 1)[1]
		with closing(db()) as connection:
			button = connection.execute("SELECT content, reply, alert, enabled FROM custom_buttons WHERE id = ? AND enabled = 1", (button_id,)).fetchone()
		if button:
			with closing(db()) as connection:
				connection.execute("UPDATE custom_buttons SET clicks = clicks + 1 WHERE id = ?", (button_id,))
				connection.commit()
			await query.answer(button["reply"] or button["content"], show_alert=bool(button["alert"]))
			await query.edit_message_text(button["reply"] or button["content"], reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("رجوع", callback_data="back:user_menu")]]))
	elif data == "back:user_menu":
		await query.edit_message_text("القائمة الرئيسية", reply_markup=menu())
	elif data.startswith("deposit:") and has_permission(query.from_user.id, "deposits"):
		await review_deposit(query, data)


async def review_deposit(query: Any, data: str) -> None:
	_, action, deposit_id = data.split(":")
	with closing(db()) as connection:
		deposit = connection.execute("SELECT * FROM deposits WHERE id = ? AND status = 'pending'", (deposit_id,)).fetchone()
		if not deposit:
			await query.edit_message_text("تمت مراجعة هذه العملية مسبقاً.")
			return
		status = "approved" if action == "approve" else "rejected"
		connection.execute("UPDATE deposits SET status = ?, reviewed_at = ? WHERE id = ?", (status, now(), deposit_id))
		connection.commit()
	if action == "approve":
		change_balance(deposit["telegram_id"], deposit["amount"])
		await query.bot.send_message(deposit["telegram_id"], f"تم قبول الشحن وإضافة {money(deposit['amount'])} إلى رصيدك.")
	else:
		await query.bot.send_message(deposit["telegram_id"], "تم رفض طلب الشحن. تواصل مع الدعم إذا كان هناك خطأ.")
	await query.edit_message_text(f"تمت مراجعة طلب الشحن #{deposit_id}: {status}")


async def pre_checkout(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
	query = update.pre_checkout_query
	if not query:
		return
	valid = False
	try:
		parts = query.invoice_payload.split(":")
		valid = len(parts) == 3 and parts[0] == "stars" and int(parts[1]) == query.from_user.id and int(parts[2]) == query.total_amount
	except (ValueError, TypeError):
		valid = False
	await query.answer(ok=valid, error_message=None if valid else "الفاتورة غير صالحة، أعد المحاولة من زر شحن الرصيد.")


async def successful_payment(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
	if not update.message or not update.effective_user or not update.message.successful_payment:
		return
	payment = update.message.successful_payment
	try:
		parts = payment.invoice_payload.split(":")
		if len(parts) != 3 or parts[0] != "stars" or int(parts[1]) != update.effective_user.id:
			raise ValueError
		stars = int(parts[2])
		if stars != payment.total_amount:
			raise ValueError
	except (ValueError, TypeError):
		await update.message.reply_text("تعذر التحقق من عملية الدفع. تواصل مع الدعم.")
		return
	amount = stars / stars_per_usd()
	before_balance = balance_of(update.effective_user.id)
	with closing(db()) as connection:
		cursor = connection.execute(
			"INSERT OR IGNORE INTO deposits(telegram_id, amount, note, status, created_at, reviewed_at, payment_method, stars, telegram_charge_id) VALUES (?, ?, ?, 'approved', ?, ?, 'telegram_stars', ?, ?)",
			(update.effective_user.id, amount, f"Telegram Stars: {stars}", now(), now(), stars, payment.telegram_payment_charge_id),
		)
		connection.commit()
	if cursor.rowcount:
		if not change_balance(update.effective_user.id, amount):
			LOGGER.error("Could not credit Stars payment for %s", update.effective_user.id)
			await update.message.reply_text("تم استلام الدفع، لكن تعذر تحديث الرصيد. تواصل مع الدعم.")
			return
		after_balance = balance_of(update.effective_user.id)
		user = update.effective_user
		username = f"@{user.username}" if user.username else "لا يوجد"
		notification = (
			"💰 عملية شراء جديدة!\n\n"
			"━━━━━━━━━━━━━━━\n\n"
			f"👤 العميل:\n• الاسم: {user.full_name}\n• الآيدي: {user.id}\n• المعرف: {username}\n• اللغة: {user.language_code or 'غير محددة'}\n\n"
			f"🛒 تفاصيل الشراء:\n\n• النوع: نجوم\n• المبلغ: {stars} ⭐\n"
			f"• رمز العملية: {payment.telegram_payment_charge_id}\n• الوقت: {formatted_time()}\n\n"
			f"💎 الرصيد:\n• قبل: {before_balance:g}\n• بعد: {after_balance:g} (+{amount:g})\n\n"
			"━━━━━━━━━━━━━━━"
		)
		for admin_id in permission_holders("deposits"):
			try:
				await context.bot.send_message(admin_id, notification)
			except Exception:
				LOGGER.warning("Could not notify admin %s about Stars payment", admin_id, exc_info=True)
		await update.message.reply_text(f"تم الدفع بنجاح وإضافة {money(amount)} إلى محفظتك مقابل {stars} نجمة.", reply_markup=menu())
	else:
		await update.message.reply_text("تم تسجيل عملية الدفع مسبقاً.", reply_markup=menu())


async def refund_stars_payment(update: Update, user_id: int, charge_id: str, admin_id: int) -> None:
	with closing(db()) as connection:
		deposit = connection.execute(
			"SELECT * FROM deposits WHERE telegram_charge_id = ? AND payment_method = 'telegram_stars'",
			(charge_id,),
		).fetchone()
	if not deposit:
		await update.message.reply_text("لم يتم العثور على عملية نجوم بهذا الرمز.")
		return
	if deposit["refunded_at"]:
		await update.message.reply_text("تم استرداد هذه العملية مسبقاً ولا يمكن استردادها مرة أخرى.")
		return
	if not change_balance(deposit["telegram_id"], -float(deposit["amount"])):
		await update.message.reply_text("لا يمكن الاسترداد لأن رصيد المستخدم أقل من قيمة العملية.")
		return
	try:
		await update.get_bot().refund_star_payment(deposit["telegram_id"], charge_id)
	except Exception as exc:
		change_balance(deposit["telegram_id"], float(deposit["amount"]))
		LOGGER.exception("Stars refund failed for %s", charge_id)
		await update.message.reply_text(f"فشل الاسترداد وتمت إعادة رصيد المستخدم: {exc}")
		return
	with closing(db()) as connection:
		connection.execute("UPDATE deposits SET refunded_at = ?, refunded_by = ?, status = 'refunded' WHERE id = ? AND refunded_at IS NULL", (now(), admin_id, deposit["id"]))
		connection.commit()
	await update.message.reply_text(f"تم استرداد {deposit['stars']} نجمة بنجاح للمستخدم {deposit['telegram_id']}.", reply_markup=admin_menu())


async def text_message(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
	if not update.message or not update.effective_user:
		return
	user_id = update.effective_user.id
	text = (update.message.text or "").strip()
	state = context.user_data.get("state")
	if maintenance_enabled() and not is_admin(user_id):
		await update.message.reply_text("البوت في وضع الصيانة حالياً. حاول لاحقاً.")
		return
	auto_reply = auto_reply_for(text)
	if auto_reply:
		await update.message.reply_text(auto_reply, reply_markup=menu())
		return
	if has_permission(user_id, "broadcast") and text.startswith("/broadcast "):
		await broadcast(update, text.removeprefix("/broadcast ").strip())
		return
	if state == "moderator_identity" and is_owner(user_id):
		identity = text.strip()
		try:
			lookup = identity if identity.startswith("@") else int(identity)
			member = await update.get_bot().get_chat(lookup)
			if member.type != "private":
				raise ValueError
			with closing(db()) as connection:
				connection.execute(
					"INSERT OR IGNORE INTO admins(telegram_id, username, display_name, role, permissions, enabled, created_at) VALUES (?, ?, ?, 'moderator', '', 1, ?)",
					(member.id, f"@{member.username}" if member.username else "", member.full_name or "", now()),
				)
				connection.execute("UPDATE admins SET username = ?, display_name = ?, enabled = 1 WHERE telegram_id = ? AND role = 'moderator'", (f"@{member.username}" if member.username else "", member.full_name or "", member.id))
				connection.commit()
			context.user_data.clear()
			await update.message.reply_text("تمت إضافة المشرف. اختر صلاحياته الآن من القائمة.", reply_markup=moderator_editor_menu(member.id, ""))
		except Exception:
			LOGGER.warning("Could not resolve moderator identity", exc_info=True)
			await update.message.reply_text("لم أجد مستخدماً خاصاً بهذا الآيدي أو المعرف. تأكد أن المستخدم بدأ محادثة مع البوت.", reply_markup=back_markup("admin:moderators"))
		return
	if state in {"button_edit_label", "button_edit_content", "button_edit_reply", "button_edit_type", "button_move"} and has_permission(user_id, "buttons"):
		button_id = context.user_data.get("button_id")
		if state == "button_edit_type" and text not in {"url", "content", "contact"}:
			await update.message.reply_text("النوع يجب أن يكون: url أو content أو contact", reply_markup=back_markup(f"button:edit:{button_id}"))
			return
		if state == "button_move":
			try:
				value = int(text)
				if value < 1:
					raise ValueError
			except ValueError:
				await update.message.reply_text("أرسل رقماً صحيحاً للموضع.", reply_markup=back_markup(f"button:edit:{button_id}"))
				return
			column, value = "position", int(text)
		else:
			column = {"button_edit_label": "label", "button_edit_content": "content", "button_edit_reply": "reply", "button_edit_type": "button_type"}[state]
			value = text
		with closing(db()) as connection:
			connection.execute(f"UPDATE custom_buttons SET {column} = ? WHERE id = ?", (value, button_id))
			connection.commit()
		context.user_data.clear()
		await update.message.reply_text("تم حفظ التعديل.", reply_markup=button_editor_menu(int(button_id)))
		return
	if state == "welcome" and is_owner(user_id):
		save_setting("welcome_text", text)
		context.user_data.clear()
		await update.message.reply_text("تم تحديث رسالة الترحيب.", reply_markup=settings_menu(user_id))
		return
	if state == "api_key" and is_owner(user_id):
		save_setting("provider_api_key", text)
		context.user_data.clear()
		await update.message.reply_text("تم تحديث مفتاح API.", reply_markup=settings_menu(user_id))
		return
	if state == "force_subscribe" and is_owner(user_id):
		save_setting("force_subscribe_channel", "" if text.casefold() == "off" else text)
		context.user_data.clear()
		await update.message.reply_text("تم تحديث القناة الإجبارية.", reply_markup=settings_menu(user_id))
		return
	if state.startswith("payment_details_") and has_permission(user_id, "deposits"):
		method = state.removeprefix("payment_details_")
		if method in {"phone", "bank"} and text:
			save_setting(f"payment_{method}_details", text)
			context.user_data.clear()
			await update.message.reply_text("تم حفظ بيانات الدفع.", reply_markup=admin_menu())
		return
	if state == "admin_credit_id" and has_permission(user_id, "deposits"):
		if not text.isdigit() or int(text) <= 0:
			await update.message.reply_text("أرسل آيدي مستخدم رقمي صحيح.")
			return
		context.user_data["credit_user_id"] = int(text)
		context.user_data["state"] = "admin_credit_amount"
		await update.message.reply_text("أرسل المبلغ بالدولار الذي تريد إضافته:", reply_markup=back_markup("admin:finance"))
		return
	if state == "admin_credit_amount" and has_permission(user_id, "deposits"):
		try:
			amount = float(text)
			if amount <= 0:
				raise ValueError
			credit_user_id = int(context.user_data["credit_user_id"])
		except (ValueError, KeyError):
			await update.message.reply_text("أرسل مبلغاً صحيحاً أكبر من صفر.")
			return
		with closing(db()) as connection:
			user = connection.execute("SELECT telegram_id, first_name, username FROM users WHERE telegram_id = ?", (credit_user_id,)).fetchone()
			if not user:
				connection.execute("INSERT OR IGNORE INTO users(telegram_id, username, first_name, language_code, created_at) VALUES (?, '', '', '', ?)", (credit_user_id, now()))
			connection.commit()
		before = balance_of(credit_user_id)
		if not change_balance(credit_user_id, amount):
			await update.message.reply_text("تعذر تحديث رصيد المستخدم.", reply_markup=admin_menu())
			return
		with closing(db()) as connection:
			connection.execute("INSERT INTO deposits(telegram_id, amount, note, status, created_at, reviewed_at, payment_method) VALUES (?, ?, ?, 'approved', ?, ?, 'admin_credit')", (credit_user_id, amount, f"شحن مباشر بواسطة المسؤول {user_id}", now(), now()))
			connection.commit()
		context.user_data.clear()
		after = balance_of(credit_user_id)
		try:
			await update.get_bot().send_message(credit_user_id, f"تم شحن محفظتك من قبل المسؤول بقيمة {money(amount)}.\nرصيدك السابق: {money(before)}\nرصيدك الحالي: {money(after)}")
		except Exception:
			LOGGER.warning("Could not notify credited user %s", credit_user_id, exc_info=True)
		await update.message.reply_text(f"تم شحن المستخدم {credit_user_id} بمبلغ {money(amount)}.", reply_markup=admin_menu())
		return
	if state == "stars_rate" and has_permission(user_id, "deposits"):
		try:
			rate = float(text)
			if rate <= 0 or rate > 1_000_000:
				raise ValueError
		except ValueError:
			await update.message.reply_text("أرسل رقماً أكبر من صفر وأقل من 1000000.")
			return
		save_setting("stars_per_usd", str(rate))
		context.user_data.clear()
		await update.message.reply_text(f"تم تحديث السعر: كل {rate:g} نجمة = 1 دولار.", reply_markup=admin_menu())
		return
	if state == "refund_stars" and has_permission(user_id, "deposits"):
		if not text or len(text) > 256 or any(char.isspace() for char in text):
			await update.message.reply_text("أرسل رمز عملية الدفع فقط دون مسافات.")
			return
		context.user_data.clear()
		await refund_stars_payment(update, user_id, text, user_id)
		return
	if state == "local_service_id" and has_permission(user_id, "tutorials"):
		if not text or "|" in text or len(text) > 64:
			await update.message.reply_text("أرسل رقم الخدمة لدى المزود فقط.", reply_markup=back_markup("admin:services"))
			return
		context.user_data["local_service"]["service_id"] = text
		context.user_data["state"] = "local_service_name"
		await update.message.reply_text("أرسل اسم الخدمة، مثال: مشاهدات منشورات تيليجرام:", reply_markup=back_markup("admin:services"))
		return
	if state == "local_service_name" and has_permission(user_id, "tutorials"):
		if not text or len(text) > 120:
			await update.message.reply_text("أرسل اسماً صحيحاً للخدمة.")
			return
		context.user_data["local_service"]["name"] = text
		context.user_data["state"] = "local_service_category"
		await update.message.reply_text("أرسل القسم، مثال: تيليجرام - مشاهدات المنشورات:", reply_markup=back_markup("admin:services"))
		return
	if state == "local_service_category" and has_permission(user_id, "tutorials"):
		if not text or len(text) > 80:
			await update.message.reply_text("أرسل اسماً صحيحاً للقسم.")
			return
		context.user_data["local_service"]["category"] = text
		context.user_data["state"] = "local_service_rate"
		await update.message.reply_text("أرسل سعر المزود لكل 1000، مثال: 0.50:", reply_markup=back_markup("admin:services"))
		return
	if state in {"local_service_rate", "local_service_minimum", "local_service_maximum"} and has_permission(user_id, "tutorials"):
		try:
			value = float(text) if state == "local_service_rate" else int(text)
			if value <= 0:
				raise ValueError
		except ValueError:
			await update.message.reply_text("أرسل رقماً موجباً صحيحاً.")
			return
		service_data = context.user_data["local_service"]
		if state == "local_service_rate":
			service_data["provider_rate"] = value
			context.user_data["state"] = "local_service_minimum"
			await update.message.reply_text("أرسل أقل كمية مسموحة، مثال: 100:", reply_markup=back_markup("admin:services"))
		elif state == "local_service_minimum":
			service_data["minimum"] = value
			context.user_data["state"] = "local_service_maximum"
			await update.message.reply_text("أرسل أكبر كمية مسموحة، مثال: 1000000:", reply_markup=back_markup("admin:services"))
		else:
			if value < service_data["minimum"]:
				await update.message.reply_text("الحد الأكبر يجب أن يكون أكبر من أو يساوي الحد الأصغر.")
				return
			service_data["maximum"] = value
			with closing(db()) as connection:
				connection.execute("INSERT OR REPLACE INTO local_services(service_id, name, category, provider_rate, minimum, maximum, refill, enabled, created_by, created_at) VALUES (?, ?, ?, ?, ?, ?, 0, 1, ?, ?)", (service_data["service_id"], service_data["name"], service_data["category"], service_data["provider_rate"], service_data["minimum"], service_data["maximum"], user_id, now()))
				connection.commit()
			context.user_data.clear()
			await update.message.reply_text("تمت إضافة الخدمة بنجاح وستظهر للمستخدمين عند فتح الخدمات.", reply_markup=services_admin_menu())
		return
	if state == "completion_channel" and is_owner(user_id):
		save_setting("completion_channel", "" if text.casefold() == "off" else text)
		context.user_data.clear()
		await update.message.reply_text("تم تحديث قناة الإكمال.", reply_markup=order_notifications_menu())
		return
	if state == "button_label" and has_permission(user_id, "buttons"):
		context.user_data["button_label"] = text
		context.user_data["state"] = "button_target" if context.user_data["button_type"] in {"url", "contact"} else "button_content"
		prompt = "أرسل الرابط، مثال: https://t.me/example" if context.user_data["state"] == "button_target" else "أرسل محتوى الرسالة التي ستظهر عند الضغط على الزر:"
		await update.message.reply_text(prompt, reply_markup=back_markup("admin:content"))
		return
	if state in {"button_target", "button_content"} and has_permission(user_id, "buttons"):
		button_type = context.user_data["button_type"]
		label = context.user_data["button_label"]
		url = text if state == "button_target" else None
		if button_type == "contact" and url and url.startswith("@"):
			url = f"https://t.me/{url[1:]}"
		if button_type in {"url", "contact"} and not url.startswith(("http://", "https://")):
			await update.message.reply_text("الرابط يجب أن يبدأ بـ http:// أو https://")
			return
		with closing(db()) as connection:
			connection.execute("INSERT INTO custom_buttons(label, content, url, button_type, created_at) VALUES (?, ?, ?, ?, ?)", (label, "فتح الرابط" if url else text, url, button_type, now()))
			connection.commit()
		context.user_data.clear()
		await update.message.reply_text("تم إنشاء الزر ونشره في القائمة الرئيسية.", reply_markup=admin_menu())
		return
	if state == "reply_keyword" and has_permission(user_id, "buttons"):
		context.user_data["reply_keyword"] = text
		context.user_data["state"] = "reply_response"
		await update.message.reply_text("أرسل الرد الذي سيظهر عند كتابة الكلمة:", reply_markup=back_markup("admin:content"))
		return
	if state == "reply_response" and has_permission(user_id, "buttons"):
		with closing(db()) as connection:
			connection.execute("INSERT OR REPLACE INTO auto_replies(keyword, response, created_at) VALUES (?, ?, ?)", (context.user_data["reply_keyword"], text, now()))
			connection.commit()
		context.user_data.clear()
		await update.message.reply_text("تم حفظ الرد التلقائي.", reply_markup=content_menu())
		return
	if state == "visibility" and has_permission(user_id, "buttons"):
		parts = text.split()
		if len(parts) != 2 or parts[0].lower() not in {"hide", "show"}:
			await update.message.reply_text("الصيغة: hide رقم_الخدمة أو show رقم_الخدمة")
			return
		save_setting(f"hidden_service:{parts[1]}", "1" if parts[0].lower() == "hide" else "0")
		context.user_data.clear()
		await update.message.reply_text("تم تحديث حالة الخدمة.", reply_markup=content_menu())
		return
	if has_permission(user_id, "settings") and state == "margin":
		try:
			margin = float(text)
			if margin < 0 or margin > 1000:
				raise ValueError
			with closing(db()) as connection:
				connection.execute("INSERT OR REPLACE INTO settings(name, value) VALUES ('margin_percent', ?)", (str(margin),))
				connection.commit()
			context.user_data.clear()
			await update.message.reply_text(f"تم تحديث الهامش إلى {margin}%", reply_markup=admin_menu())
		except ValueError:
			await update.message.reply_text("أرسل رقماً بين 0 و1000.")
		return
	if state == "tutorial" and has_permission(user_id, "tutorials"):
		try:
			service_id, content = [part.strip() for part in text.split("|", 1)]
			with closing(db()) as connection:
				connection.execute("INSERT OR REPLACE INTO tutorials(service_id, content, updated_by, updated_at) VALUES (?, ?, ?, ?)", (service_id, content, user_id, now()))
				connection.commit()
			context.user_data.clear()
			await update.message.reply_text("تم حفظ شرح الخدمة.", reply_markup=admin_menu())
		except ValueError:
			await update.message.reply_text("الصيغة: رقم_الخدمة | نص التعليمات")
		return
	if state == "moderator" and is_owner(user_id):
		parts = text.split()
		if len(parts) < 2 or parts[0] not in {"add", "remove"} or not parts[1].isdigit():
			await update.message.reply_text("الصيغة: add|remove رقم_المستخدم الصلاحيات")
			return
		moderator_id = int(parts[1])
		with closing(db()) as connection:
			if parts[0] == "add":
				permissions = parts[2] if len(parts) > 2 else "deposits,tutorials,buttons,support,broadcast"
				connection.execute("INSERT OR REPLACE INTO admins(telegram_id, role, permissions, created_at) VALUES (?, 'moderator', ?, ?)", (moderator_id, permissions, now()))
			else:
				connection.execute("DELETE FROM admins WHERE telegram_id = ? AND role = 'moderator'", (moderator_id,))
			connection.commit()
		context.user_data.clear()
		await update.message.reply_text("تم تحديث صلاحيات المشرف.", reply_markup=admin_menu())
		return
	if state == "link":
		context.user_data.update(state="quantity", link=text)
		await update.message.reply_text("أرسل الكمية المطلوبة بالأرقام:", reply_markup=back_markup("user_menu"))
		return
	if state == "quantity":
		try:
			quantity = int(text)
			service = service_cache[context.user_data["service_id"]]
			if not service.minimum <= quantity <= service.maximum:
				raise ValueError
		except (ValueError, KeyError):
			await update.message.reply_text("الكمية غير صحيحة أو خارج حدود الخدمة.", reply_markup=back_markup("user_menu"))
			return
		cost = customer_price(service, quantity)
		context.user_data.update(state="confirm", quantity=quantity, cost=cost)
		keyboard = InlineKeyboardMarkup([[InlineKeyboardButton("تأكيد الطلب", callback_data="confirm_order"), InlineKeyboardButton("رجوع", callback_data="cancel")]])
		await update.message.reply_text(f"الخدمة: {service.name}\nالكمية: {quantity}\nالتكلفة: {money(cost)}\nرصيدك: {money(balance_of(user_id))}", reply_markup=keyboard)
		return
	if state == "deposit":
		await create_deposit(update, text, None, context.user_data.get("deposit_method", "phone"))
		return
	if state == "stars_amount":
		try:
			amount = float(text)
			stars = int(round(amount * stars_per_usd()))
			if amount <= 0 or stars < 1:
				raise ValueError
		except ValueError:
			await update.message.reply_text("أرسل مبلغاً صحيحاً بالدولار، مثال: 1 أو 5.")
			return
		context.user_data.clear()
		try:
			await update.message.reply_invoice(
				title="شحن محفظة البوت",
				description=f"إضافة {stars / stars_per_usd():.2f} دولار إلى محفظتك مقابل {stars} نجمة",
				payload=f"stars:{user_id}:{stars}",
				provider_token="",
				currency="XTR",
				prices=[LabeledPrice("رصيد المحفظة", stars)],
			)
		except Exception as exc:
			LOGGER.exception("Could not send Stars invoice")
			await update.message.reply_text(f"تعذر إنشاء فاتورة النجوم: {exc}", reply_markup=menu())
		return
	await update.message.reply_text("استخدم /start لعرض القائمة.", reply_markup=menu())


async def create_deposit(update: Update, text: str, proof_file_id: str | None, payment_method: str = "phone") -> None:
	try:
		amount = float(text.split()[0])
		if amount <= 0:
			raise ValueError
	except (ValueError, IndexError):
		await update.message.reply_text("أرسل مبلغاً صحيحاً، مثال: 10 رقم العملية")
		return
	with closing(db()) as connection:
		cursor = connection.execute("INSERT INTO deposits(telegram_id, amount, note, proof_file_id, created_at, payment_method) VALUES (?, ?, ?, ?, ?, ?)", (update.effective_user.id, amount, text, proof_file_id, now(), payment_method))
		deposit_id = cursor.lastrowid
		connection.commit()
	keyboard = InlineKeyboardMarkup([[InlineKeyboardButton("قبول", callback_data=f"deposit:approve:{deposit_id}"), InlineKeyboardButton("رفض", callback_data=f"deposit:reject:{deposit_id}")]])
	method_label = {"phone": "رصيد الهاتف", "bank": "تحويل بنكي"}.get(payment_method, payment_method)
	for admin_id in permission_holders("deposits"):
		await update.get_bot().send_message(admin_id, f"طلب شحن #{deposit_id}\nطريقة الدفع: {method_label}\nالمستخدم: {update.effective_user.id}\nالمبلغ: {money(amount)}\nالإثبات: {text}", reply_markup=keyboard)
	await update.message.reply_text("تم إرسال طلب الشحن للمراجعة. سيصلك إشعار بعد الاعتماد.", reply_markup=menu())


async def photo_message(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
	if not update.message or not update.effective_user:
		return
	if context.user_data.get("state") == "tutorial" and has_permission(update.effective_user.id, "tutorials"):
		await save_tutorial_media(update, update.message.caption or "", update.message.photo[-1].file_id, "photo")
		context.user_data.clear()
		return
	if context.user_data.get("state") != "deposit":
		return
	caption = update.message.caption or ""
	await create_deposit(update, caption, update.message.photo[-1].file_id, context.user_data.get("deposit_method", "phone"))
	context.user_data.clear()


async def video_message(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
	if not update.message or not update.effective_user or context.user_data.get("state") != "tutorial":
		return
	if has_permission(update.effective_user.id, "tutorials") and update.message.video:
		await save_tutorial_media(update, update.message.caption or "", update.message.video.file_id, "video")
		context.user_data.clear()


async def save_tutorial_media(update: Update, text: str, file_id: str, media_type: str) -> None:
	try:
		service_id, content = [part.strip() for part in text.split("|", 1)]
		with closing(db()) as connection:
			connection.execute("INSERT OR REPLACE INTO tutorials(service_id, content, photo_file_id, media_type, updated_by, updated_at) VALUES (?, ?, ?, ?, ?, ?)", (service_id, content, file_id, media_type, update.effective_user.id, now()))
			connection.commit()
		await update.message.reply_text("تم حفظ شرح الخدمة مع الوسائط.", reply_markup=admin_menu())
	except ValueError:
		await update.message.reply_text("أرفق الصورة أو الفيديو واكتب في الوصف: رقم_الخدمة | نص التعليمات")


async def confirm_order(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
	query = update.callback_query
	if not query or query.data != "confirm_order":
		return
	await query.answer()
	values = context.user_data
	try:
		service = service_cache[values["service_id"]]
		cost = float(values["cost"])
		if not change_balance(query.from_user.id, -cost):
			await query.edit_message_text("رصيدك غير كافٍ.", reply_markup=menu())
			return
		provider_id = await provider.add_order(service.service_id, values["link"], int(values["quantity"]))
		with closing(db()) as connection:
			connection.execute("INSERT INTO orders(telegram_id, provider_order_id, service_id, service_name, link, quantity, cost, status, notified_status, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, 'pending', 'received', ?)", (query.from_user.id, provider_id, service.service_id, service.name, values["link"], values["quantity"], cost, now()))
			connection.commit()
		with closing(db()) as connection:
			order = connection.execute("SELECT * FROM orders WHERE telegram_id = ? AND provider_order_id = ? ORDER BY id DESC LIMIT 1", (query.from_user.id, provider_id)).fetchone()
		if order:
			await send_order_notification(context.bot, order, "received")
		await query.edit_message_text(f"تم إنشاء الطلب بنجاح. رقم الطلب: {provider_id}\nالتكلفة: {money(cost)}", reply_markup=menu())
	except Exception as exc:
		change_balance(query.from_user.id, float(values.get("cost", 0)))
		LOGGER.exception("Order creation failed")
		await query.edit_message_text(f"فشل إنشاء الطلب وتمت إعادة المبلغ إلى رصيدك: {exc}", reply_markup=menu())
	finally:
		context.user_data.clear()


async def cancel(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
	if update.callback_query:
		await update.callback_query.answer()
		await update.callback_query.edit_message_text("تم إلغاء العملية.", reply_markup=menu())
	context.user_data.clear()


async def order_status(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
	if not update.message or not context.args:
		await update.effective_message.reply_text("الاستخدام: /status رقم_الطلب")
		return
	try:
		status = await provider.order_status(context.args[0])
		await update.message.reply_text("\n".join(f"{key}: {value}" for key, value in status.items()))
	except Exception as exc:
		await update.message.reply_text(f"تعذر جلب الحالة: {exc}")


async def refill_order(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
	if not update.message or not update.effective_user or not context.args:
		await update.effective_message.reply_text("الاستخدام: /refill رقم_الطلب")
		return
	provider_order_id = context.args[0]
	with closing(db()) as connection:
		order = connection.execute(
			"SELECT service_id FROM orders WHERE telegram_id = ? AND provider_order_id = ?",
			(update.effective_user.id, provider_order_id),
		).fetchone()
	if not order:
		await update.message.reply_text("الطلب غير موجود ضمن طلباتك.")
		return
	try:
		refill_id = await provider.refill(provider_order_id)
		await update.message.reply_text(f"تم إرسال طلب التعويض. الرقم: {refill_id}")
	except Exception as exc:
		await update.message.reply_text(f"تعذر طلب التعويض: {exc}")


async def admin(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
	if update.effective_user and is_admin(update.effective_user.id):
		await update.effective_message.reply_text("لوحة التحكم", reply_markup=admin_menu())


async def set_margin_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
	if not update.effective_user or not has_permission(update.effective_user.id, "settings") or not context.args:
		return
	try:
		margin = float(context.args[0])
		if margin < 0 or margin > 1000:
			raise ValueError
		save_setting("margin_percent", str(margin))
		await update.effective_message.reply_text(f"تم تحديث الهامش إلى {margin}%")
	except ValueError:
		await update.effective_message.reply_text("أرسل نسبة بين 0 و1000.")


async def maintenance_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
	if not update.effective_user or not is_owner(update.effective_user.id) or not context.args or context.args[0] not in {"on", "off"}:
		return
	save_setting("maintenance_mode", "1" if context.args[0] == "on" else "0")
	await update.effective_message.reply_text("تم تحديث وضع الصيانة.")


async def api_key_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
	if not update.effective_user or not is_owner(update.effective_user.id) or not context.args:
		return
	save_setting("provider_api_key", context.args[0])
	await update.effective_message.reply_text("تم تحديث مفتاح API. احذف رسالة المفتاح من سجل المحادثة.")


async def welcome_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
	if not update.effective_user or not is_owner(update.effective_user.id) or not context.args:
		return
	save_setting("welcome_text", " ".join(context.args))
	await update.effective_message.reply_text("تم تحديث رسالة الترحيب.")


async def content_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
	if not update.effective_user or not has_permission(update.effective_user.id, "buttons"):
		return
	text = " ".join(context.args)
	try:
		label, content, *url = [part.strip() for part in text.split("|", 2)]
		with closing(db()) as connection:
			connection.execute("INSERT INTO custom_buttons(label, content, url, created_at) VALUES (?, ?, ?, ?)", (label, content, url[0] if url else None, now()))
			connection.commit()
		await update.effective_message.reply_text("تمت إضافة الزر.")
	except ValueError:
		await update.effective_message.reply_text("الصيغة: /button الاسم | النص | الرابط الاختياري")


async def reply_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
	if not update.effective_user or not has_permission(update.effective_user.id, "buttons"):
		return
	try:
		keyword, response = [part.strip() for part in " ".join(context.args).split("|", 1)]
		with closing(db()) as connection:
			connection.execute("INSERT OR REPLACE INTO auto_replies(keyword, response, created_at) VALUES (?, ?, ?)", (keyword, response, now()))
			connection.commit()
		await update.effective_message.reply_text("تم حفظ الرد التلقائي.")
	except ValueError:
		await update.effective_message.reply_text("الصيغة: /reply الكلمة | الرد")


async def service_visibility_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
	if not update.effective_user or not has_permission(update.effective_user.id, "buttons") or len(context.args) != 1:
		return
	command = update.message.text.split()[0].lower()
	save_setting(f"hidden_service:{context.args[0]}", "1" if command == "/hide" else "0")
	await update.effective_message.reply_text("تم تحديث ظهور الخدمة.")


async def balance_adjust_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
	if not update.effective_user or not has_permission(update.effective_user.id, "deposits") or len(context.args) != 2:
		return
	try:
		user_id, amount = int(context.args[0]), float(context.args[1])
		if amount <= 0 or not change_balance(user_id, amount):
			raise ValueError
		await update.effective_message.reply_text(f"تمت إضافة {money(amount)} للمستخدم {user_id}.")
	except ValueError:
		await update.effective_message.reply_text("الصيغة: /credit رقم_المستخدم المبلغ")


async def balance_remove_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
	if not update.effective_user or not has_permission(update.effective_user.id, "deposits") or len(context.args) != 2:
		return
	try:
		user_id, amount = int(context.args[0]), float(context.args[1])
		if amount <= 0 or not change_balance(user_id, -amount):
			raise ValueError
		await update.effective_message.reply_text(f"تم خصم {money(amount)} من المستخدم {user_id}.")
	except ValueError:
		await update.effective_message.reply_text("الصيغة: /debit رقم_المستخدم المبلغ")


async def broadcast(update: Update, text: str) -> None:
	with closing(db()) as connection:
		users = connection.execute("SELECT telegram_id FROM users").fetchall()
	sent = 0
	for user in users:
		try:
			await update.get_bot().send_message(user["telegram_id"], text)
			sent += 1
			await asyncio.sleep(0.05)
		except Exception:
			LOGGER.warning("Broadcast failed for %s", user["telegram_id"])
	await update.message.reply_text(f"تم الإرسال إلى {sent} مستخدم.")


def build_application() -> Application:
	if not BOT_TOKEN:
		raise RuntimeError("ضع BOT_TOKEN في ملف .env قبل التشغيل")
	init_db()
	application = ApplicationBuilder().token(BOT_TOKEN).build()
	application.add_handler(CommandHandler("start", start))
	application.add_handler(CommandHandler("admin", admin))
	application.add_handler(CommandHandler("status", order_status))
	application.add_handler(CommandHandler("refill", refill_order))
	application.add_handler(CommandHandler("setmargin", set_margin_command))
	application.add_handler(CommandHandler("maintenance", maintenance_command))
	application.add_handler(CommandHandler("api_key", api_key_command))
	application.add_handler(CommandHandler("welcome", welcome_command))
	application.add_handler(CommandHandler("button", content_command))
	application.add_handler(CommandHandler("reply", reply_command))
	application.add_handler(CommandHandler("hide", service_visibility_command))
	application.add_handler(CommandHandler("show", service_visibility_command))
	application.add_handler(CommandHandler("credit", balance_adjust_command))
	application.add_handler(CommandHandler("debit", balance_remove_command))
	application.add_handler(ChatMemberHandler(my_chat_member, ChatMemberHandler.MY_CHAT_MEMBER))
	application.add_handler(PreCheckoutQueryHandler(pre_checkout))
	application.add_handler(CallbackQueryHandler(confirm_order, pattern="^confirm_order$"))
	application.add_handler(CallbackQueryHandler(cancel, pattern="^cancel$"))
	application.add_handler(CallbackQueryHandler(callback))
	application.add_handler(MessageHandler(filters.PHOTO, photo_message))
	application.add_handler(MessageHandler(filters.VIDEO, video_message))
	application.add_handler(MessageHandler(filters.SUCCESSFUL_PAYMENT, successful_payment))
	application.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, text_message))
	if application.job_queue:
		application.job_queue.run_repeating(monitor_orders, interval=60, first=15, name="order-status-monitor")
	return application


if __name__ == "__main__":
	asyncio.set_event_loop(asyncio.new_event_loop())
	build_application().run_polling(allowed_updates=Update.ALL_TYPES)
