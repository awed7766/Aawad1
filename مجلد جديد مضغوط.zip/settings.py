"""Static environment settings for the Telegram bot.

Runtime-editable settings such as margin and maintenance mode are stored in SQLite.
Keep secrets in .env; never commit that file.
"""

import os
from dataclasses import dataclass

from dotenv import load_dotenv

load_dotenv()


def parse_ids(value: str) -> frozenset[int]:
    return frozenset(int(item.strip()) for item in value.split(",") if item.strip().isdigit())


@dataclass(frozen=True)
class Settings:
    bot_token: str
    database_path: str
    currency: str
    support_username: str
    owner_ids: frozenset[int]
    legacy_admin_ids: frozenset[int]
    provider_api_url: str
    provider_api_key: str
    force_subscribe_channel: str


CONFIG = Settings(
    bot_token=os.getenv("BOT_TOKEN", ""),
    database_path=os.getenv("DATABASE_PATH", "bot.sqlite3"),
    currency=os.getenv("CURRENCY", "USD"),
    support_username=os.getenv("SUPPORT_USERNAME", ""),
    owner_ids=parse_ids(os.getenv("OWNER_IDS", os.getenv("ADMIN_IDS", ""))),
    legacy_admin_ids=parse_ids(os.getenv("ADMIN_IDS", "")),
    provider_api_url=os.getenv("PROVIDER_API_URL", "").rstrip("/"),
    provider_api_key=os.getenv("PROVIDER_API_KEY", ""),
    force_subscribe_channel=os.getenv("FORCE_SUBSCRIBE_CHANNEL", ""),
)

DEFAULT_MARGIN_PERCENT = os.getenv("DEFAULT_MARGIN_PERCENT", "30")
MODERATOR_DEFAULT_PERMISSIONS = "deposits,tutorials,buttons,support,broadcast"
